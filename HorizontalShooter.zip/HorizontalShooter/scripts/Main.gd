extends Node2D

@export var enemy_scene: PackedScene = preload("res://scenes/Enemy.tscn")
@export var spawn_interval: float = 1.4

var score: int = 0
var spawn_timer: float = 1.0

@onready var player = $Player
@onready var move_joystick: VirtualJoystick = $UI/MoveJoystick
@onready var aim_joystick: VirtualJoystick = $UI/AimJoystick
@onready var score_label: Label = $UI/ScoreLabel
@onready var health_label: Label = $UI/HealthLabel
@onready var game_over_label: Label = $UI/GameOverLabel

func _ready() -> void:
	randomize()
	player.setup(move_joystick, aim_joystick)
	game_over_label.visible = false

func _process(delta: float) -> void:
	spawn_timer -= delta
	if spawn_timer <= 0.0:
		spawn_timer = spawn_interval
		spawn_enemy()

func spawn_enemy() -> void:
	var e = enemy_scene.instantiate()
	var screen_size = get_viewport_rect().size
	var side = randi() % 4
	var pos = Vector2.ZERO
	match side:
		0:
			pos = Vector2(-40, randf() * screen_size.y)
		1:
			pos = Vector2(screen_size.x + 40, randf() * screen_size.y)
		2:
			pos = Vector2(randf() * screen_size.x, -40)
		_:
			pos = Vector2(randf() * screen_size.x, screen_size.y + 40)
	e.global_position = pos
	add_child(e)

func add_score(amount: int) -> void:
	score += amount
	score_label.text = "Очки: %d" % score

func update_health(hp: int) -> void:
	health_label.text = "Здоровье: %d" % max(hp, 0)

func game_over() -> void:
	game_over_label.visible = true
	get_tree().paused = true

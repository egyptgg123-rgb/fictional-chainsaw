extends CharacterBody2D

@export var speed: float = 110.0
@export var health: int = 3
@export var contact_damage: int = 1

var damage_cooldown: float = 0.0

func _ready() -> void:
	add_to_group("enemy")

func _physics_process(delta: float) -> void:
	damage_cooldown -= delta
	var player = get_tree().get_first_node_in_group("player")
	if player:
		var dir = (player.global_position - global_position).normalized()
		velocity = dir * speed
		move_and_slide()
	for i in get_slide_collision_count():
		var col = get_slide_collision(i)
		var other = col.get_collider()
		if other and other.is_in_group("player") and other.has_method("take_damage") and damage_cooldown <= 0.0:
			other.take_damage(contact_damage)
			damage_cooldown = 1.0

func take_damage(amount: int) -> void:
	health -= amount
	if health <= 0:
		var main = get_tree().current_scene
		if main.has_method("add_score"):
			main.add_score(10)
		queue_free()

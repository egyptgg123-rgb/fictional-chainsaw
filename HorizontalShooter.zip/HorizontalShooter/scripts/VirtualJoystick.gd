extends Control
class_name VirtualJoystick

@export var joystick_radius: float = 100.0
@export var knob_radius: float = 45.0

var touch_index: int = -1
var knob_offset: Vector2 = Vector2.ZERO
var output: Vector2 = Vector2.ZERO

const MOUSE_INDEX := 1000

func _ready() -> void:
	set_process_input(true)

func _center() -> Vector2:
	return size / 2.0

func _draw() -> void:
	var center = _center()
	draw_circle(center, joystick_radius, Color(1, 1, 1, 0.12))
	draw_arc(center, joystick_radius, 0, TAU, 32, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(center + knob_offset, knob_radius, Color(1, 1, 1, 0.55))

func _to_local(global_pos: Vector2) -> Vector2:
	return get_global_transform().affine_inverse() * global_pos

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var local_pos = _to_local(event.position)
		if event.pressed:
			if touch_index == -1 and get_rect().has_point(local_pos):
				touch_index = event.index
				_update_knob(local_pos)
				get_viewport().set_input_as_handled()
		else:
			if event.index == touch_index:
				_release()
	elif event is InputEventScreenDrag:
		if event.index == touch_index:
			_update_knob(_to_local(event.position))
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var local_pos = _to_local(event.position)
		if event.pressed:
			if touch_index == -1 and get_rect().has_point(local_pos):
				touch_index = MOUSE_INDEX
				_update_knob(local_pos)
		else:
			if touch_index == MOUSE_INDEX:
				_release()
	elif event is InputEventMouseMotion and touch_index == MOUSE_INDEX:
		_update_knob(_to_local(event.position))

func _update_knob(local_pos: Vector2) -> void:
	var center = _center()
	var dir = local_pos - center
	var dist = min(dir.length(), joystick_radius)
	knob_offset = dir.normalized() * dist if dir.length() > 0.001 else Vector2.ZERO
	output = knob_offset / joystick_radius
	queue_redraw()

func _release() -> void:
	touch_index = -1
	knob_offset = Vector2.ZERO
	output = Vector2.ZERO
	queue_redraw()

func get_output() -> Vector2:
	return output

func is_active() -> bool:
	return touch_index != -1

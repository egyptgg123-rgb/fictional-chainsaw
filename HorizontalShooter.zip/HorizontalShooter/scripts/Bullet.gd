extends Area2D

@export var speed: float = 750.0
@export var lifetime: float = 2.5

var direction: Vector2 = Vector2.RIGHT

func _ready() -> void:
	get_tree().create_timer(lifetime).timeout.connect(queue_free)

func set_direction(dir: Vector2) -> void:
	direction = dir
	rotation = dir.angle()

func _physics_process(delta: float) -> void:
	position += direction * speed * delta

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("enemy") and body.has_method("take_damage"):
		body.take_damage(1)
		queue_free()

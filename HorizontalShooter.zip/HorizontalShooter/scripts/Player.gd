extends CharacterBody2D

@export var speed: float = 320.0
@export var fire_rate: float = 0.2
@export var max_health: int = 5
@export var bullet_scene: PackedScene = preload("res://scenes/Bullet.tscn")

var health: int
var aim_direction: Vector2 = Vector2.RIGHT
var fire_timer: float = 0.0

var move_joystick: VirtualJoystick = null
var aim_joystick: VirtualJoystick = null

func _ready() -> void:
	add_to_group("player")
	health = max_health

func setup(move_stick: VirtualJoystick, aim_stick: VirtualJoystick) -> void:
	move_joystick = move_stick
	aim_joystick = aim_stick

func _physics_process(delta: float) -> void:
	var move_vec = Vector2.ZERO
	if move_joystick:
		move_vec = move_joystick.get_output()
	velocity = move_vec * speed
	move_and_slide()

	if aim_joystick and aim_joystick.is_active():
		var aim_vec = aim_joystick.get_output()
		if aim_vec.length() > 0.25:
			aim_direction = aim_vec.normalized()
			rotation = aim_direction.angle()
			fire_timer -= delta
			if fire_timer <= 0.0:
				fire_timer = fire_rate
				shoot()
	else:
		fire_timer = 0.0

func shoot() -> void:
	var b = bullet_scene.instantiate()
	get_parent().add_child(b)
	b.global_position = global_position + aim_direction * 40.0
	b.set_direction(aim_direction)

func take_damage(amount: int) -> void:
	health -= amount
	var main = get_tree().current_scene
	if main.has_method("update_health"):
		main.update_health(health)
	if health <= 0:
		if main.has_method("game_over"):
			main.game_over()
		queue_free()
